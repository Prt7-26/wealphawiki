---
layout: post
title:  "Werner Linde Probability Theory"
date:   2025-03-04 13:10:00 +0800
categories: Math Probablity Textbook
tags: Math Probablity Textbook
---

*Prof. Dr. Werner Linde 
Friedrich-Schiller-Universität Jena
Fakultät für Mathematik & Informatik
Institut für Stochastik
Prof. für Stochastische Analysis
D-07737 Jena
Werner.Linde@mathematik.uni-jena.de
and
University of Delaware
Department of Mathematical Sciences
501 Ewing Hall
Newark DE, 19716
lindew@udel.edu*

#### Link:[Werner Linde Probability Theory](/raw_file/概率论与数理统计_提纲（更新贝叶斯统计）.pdf)

![1](/assets/images/article/probability-theory/1.jpg)

![2](/assets/images/article/probability-theory/2.jpg)

![3](/assets/images/article/probability-theory/3.jpg)

![4](/assets/images/article/probability-theory/4.jpg)

![5](/assets/images/article/probability-theory/5.jpg)
